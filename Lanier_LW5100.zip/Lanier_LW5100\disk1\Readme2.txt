README SUPPLEMENT FOR PS DRIVERS
Last Modified: 2012/10/29

[How to install/uninstall PS printer driver]
*Installing PS printer driver
 (Windows XP/Server2003/Vista/Server2008/Windows7/Server2012/Windows8)
  (1)Open "(OS)\(Language)\DISK1", and then double-click the Setup.exe.
  (2)Follow the instructions on the Add Printer Wizard.
  (3)Restart your computer.

 (Macintosh)
  (1)Open "PS Driver:(Language):Disk1", and then double-click the installer 
     icon.
  (2)Follow the instructions on the screen.
  (3)Restart your computer.
  (4)Open "Printer Descriptions:(Language):Disk1", and Drag the PPD file 
     and Plugin file into "System Folder:Extensions:Printer Descriptions".
  (5)Select PPD of the target printer from the following PPD selection 
     dialog by clicking "Auto" in "Chooser" or Clicking "PPD".
  (6)Restart your computer.

*Uninstalling PS printer driver
 (Windows XP/Server2003)
  (1)Open "Control Panel" -> "Printers".
  (2)Delete the printer icon.
  (3)Select "File" -> "Server Properties".
  (4)Select "Drivers" tab.
  (5)Select a driver from "Installed printer drivers" and push the Remove 
     button.
  (6)Restart your computer.

 (Windows Vista/Server2008)
  (1)Open "Control Panel" -> "Printers".
  (2)Select the printer icon.
  (3)Click right button -> "Run as administrator" -> "Delete".
  (4)Click right button -> "Run as administrator" -> "Server Properties".
  (5)Select "Drivers" tab.
  (6)Select the driver from "Installed printer drivers" and push the Remove 
     button.
  (7)Select "Remove driver and driver package.".
  (8)Restart your computer.

 (Windows 7/Server2012/Windows 8)
  (1)Open "Control Panel" -> "Devices and Printers".
  (2)Select the printer icon.
  (3)Click right button -> "Remove Device".
  (4)Click "Print Server Properties".
  (5)Select "Drivers" tab.
  (6)Select the driver from "Installed printer drivers" and push the Remove 
     button.
  (7)Select "Remove driver and driver package.".
  (8)Restart your computer.

 (Macintosh)
  (1)Delete Printer icon from DeskTop.
  (2)Delete the PPD file and the Plugin file from "System Folder:Extension:
     Printer Descriptions" folder.
  (3)Delete the PPD file from "System Folder:Preferences:Printing Prefs:
     Parsed PPD Folder" folder.
  (4)Delete "Adobe PS Prefs" file from "System Folder:Preferences:
     Printing Prefs" folder.
  (5)Delete "PSPrinter Prefs" file from "System Folder:Preferences" folder.
  (6)Restart your computer.

*We recommend performing a fresh install for any existing PS drivers 
installed for your device.

[Notes/Limitations]
1. Note for HP LJ8100 users.
The older Hewlett Packard LaserJet 8100 PCL 6 driver may interfere with 
the PostScript driver. To avoid this problem use LaserJet 8100 PCL6 driver 
V4.3.2.38 or later.

2. Collation
When printing multiple copies, turn off collation in the application and 
turn "Collate" on, on "Detailed Settings" -> "Menu" -> "Finishing". 
With some applications, collation may significantly slow down your computer.
And, some functions may not work correctly.

3. Sample Print/Locked Print/Hold Print/Stored Print/Store and Normal Print(*1)/
Send to Document Server(*2) without HDD.
(Windows XP/Server2003/Vista/Server2008/Windows7/Server2012/Windows8, Macintosh)
When the HDD is not installed, the printer do not support Sample Print, 
Locked Print, Hold Print, Stored Print, Store and Normal Print(*1),
Send to Document Server(*2), and these are automatically disabled. The printer 
will print the job as Normal Print.
Even though the HDD is not installed, "Sample Print", "Locked Print", 
"Hold Print", "Stored Print", "Store and Normal Print"(*1) and
"Send to Document Server"(*2) can be selected in the driver.
*1:Macintosh = Store and Print
*2:Macintosh = Document Server

4. Printing from NetScape4.7
(Macintosh)
In Printing with NetScape 4.7, it may cause gridlock and the termination 
of the application in use.
If you use NetScape, be sure to use NetScape 6 or later.

5. MS Word98 document with mixed orientation.
(Macintosh)
Printing of Macintosh MS Word98 document with mixed paper orientation may 
produce unexpected result if multiple copies, staple, or duplex is selected.

6. Staple/Punch
(Windows XP/Server2003/Vista/Server2008/Windows7/Server2012/Windows8, Macintosh)
When setting staple or punch, specify Finisher Tray for the Destination.
If print without setting as above, staple/punch will be cancelled.

7. Punch
(Windows XP/Server2003/Vista/Server2008/Windows7/Server2012/Windows8, Macintosh)
Any punch type (2-hole, 3-hole, 4-hole, etc.) can be configured by 
the printer driver. However the configured punch type will be cancelled 
if it is not supported by the target printer's punch unit.

8. Orientation Override
When printing in landscape with the Staple/Punch/Z-Folding functions, 
the positions of the staple, punch or z-fold might not be as specified.
To position the staple, punch or z-fold differently, 
please try any of the following:
  a. Select "Landscape" for the "Orientation Override" setting.
  b. Select "Rotated Landscape" for the "Orientation" setting.
  c. Select "Off" for the "Orientation Override" setting, and enable the 
     "Rotate by 180 degrees" setting.

9. Printing from PageMaker
(Macintosh)
When printing a document from Macintosh PageMaker, the printer may show 
"Load Letter" on the operation panel and wait for letter paper.
In order to avoid this wait, set letter paper in one of the input tray, or 
turn off Macintosh "Background Print".
(Note you have to turn off "Background Print" from the Finder.)

10. Paper Type
Some paper types can only be fed from Bypass Tray, such as Labels, Thick, 
Transparency, etc.
If you want to specify one of these paper types, please set the Paper Source 
to Bypass Tray not to AutoSelect Tray.

11. Watermark and QuarkXpress 4.1
(Macintosh)
QuarkXpress 4.1 document may not be printed as expected if Watermark 
is selected.

12. Custom Size Setup
A warning message might be displayed on a PC when Custom paper sizes 
are configured even if the custom paper sizes are within the minimum/maximum 
size limits. Alternatively, a job will be cancelled with no warning message 
shown on the PC if custom paper sizes are NOT within the minimum/maximum size 
limits. In either case, please enlarge/reduce the values to be more/less than 
the entered values even if they are within the available range.

13. Custom Size setting
(Mac OS X Classic Mode)
If click "OK"button without naming Custom Size newly created on Mac OS X 
Classic Mode, application may be terminated.
When set Custom Size on Mac OS X Classic Mode, be sure to enter the newly 
created Custom Size name before click "OK" button.

14. Custom Size Setup
(Macintosh)
Due to an Adobe PS limitation, the largest custom paper size that can 
be configured using the PS driver is 36.00 x 273.06inches (91.44 x 
693.57cm), even though the printer itself supports custom sizes larger 
than this.

15. Printing Custom Size Document from MS-Word
(Windows XP/Server2003/Vista/Server2008/Windows7/Server2012/Windows8)
When printing MS Word document using Custom Size, the document may not as 
expected.

16. Data Format
(Windows XP/Server2003/Vista/Server2008/Windows7/Server2012/Windows8)
Be sure to select "ASCII" to perform "Output Protocol".
If set to "BCP" or "Binary" to perform above operation, it may cause 
PS error or incorrect setting of numbers of copies.

17. Separator Page
(Windows XP/Server2003/Vista/Server2008/Windows7/Server2012/Windows8)
If a Separator Page is selected, some document may not be printed 
as expected.

18. Printing from PageMaker
(Macintosh)
If print with "Sample Print", "Locked Print", "Hold Print", "Stored Print",
"Store and Print", "Document Server" or "User Code" with the application 
except PageMaker and print with PageMaker after that, the previous setting 
of "Sample Print", "Locked Print", "Hold Print", "Stored Print", "Store 
and Print", "Document Server" or "User Code" is succeeded to the next 
printing with PageMaker.

19. Additional Page Count in Duplex Printing
An extra page is added to the end of odd-paged duplex jobs.
The added page might be incremented in the printer's counter.

20. Form To Tray Assignment
(Windows XP/Server2003/Vista/Server2008/Windows7/Server2012/Windows8)
Do not select "Form To Tray Assignment" item in "Device setting" tab.

21. Page Layout (Booklet) function
Booklet printing does not operate properly in printing under Acrobat.

22. Disorder when pressing "Stop"button in using Mac OS X Classic Mode 
(Macintosh)
If stop printing with "Stop" button in using the printer with Mac OS X 
Classic Mode, sometimes printer freezes with "Waiting..." status.

23. Preprinted, Prepunched and Letterhead paper types
If use Preprinted, Prepunched or Letterhead paper types for the printing of 
Landscape document, it might be printed with the unexpected orientation.

24. Printing the document with the plural Simplified Chinese fonts.
(Windows XP)
The document with the plural Simplified Chinese fonts might not be printed 
as expected.

25. Printing from PageMaker
If you use PageMaker in the Simplified Chinese environment, please use 
the English-language version of PPD file.
When PageMaker is used for the Simplified Chinese-language version's PPD 
file, the items of "Destination" may not be displayed.

26. Printing from Visio2002 with resolution of 1200dpi
Printing from Visio2002 with resolution of 1200dpi may not be performed
properly. In such case, set the resolution lower than 600 dpi.

27. Print From Microsoft Word enabling Slip Sheet
If print from Microsoft Word enabling Slip Sheet, Slip Sheet feeding may
not be conducted properly. In this case, perform printing after selecting
"Detailed Settings" -> "Menu" -> "Paper" -> "Paper Source" -> 
"Automatically Select"

28. Output Protocol
When output destination of installed driver is network port, output protocol
will be set to TBCP. If redirect the output to LPT1 or USB port remaining
the above setting, PS Error may occur. If redirect the output destination from
network port to LPT1 or USB port, please set the output protocol to ASCII.

29. Displayed file names on the operation panel.
If print a data whose file name includes Chinese, Korean, etc.(languages 
other than Latin1), the file name will not be displayed correctly on the 
operation panel.

30. CMYK used for Black and White Documents
Black and White documents might be printed in full color (CMYK).
To ensure that the job prints using pure Black (K), please change the 
color mode to "Black and White".

31. Image Smoothing
When "Image Smoothing" applied to image data with IndexColor mode, 
the printing quality of the image may not be the best.
Please turn "Image Smoothing" off before printing under the circumstances.

32. Fit to paper
(Windows XP/Server2003/Vista/Server2008/Windows7/Server2012/Windows8, Macintosh)
The "Fit to paper" function does not work when using custom paper size.

33. ICM Method
JobReset will occur under the following settings:
Select "ICM Handled by Printer" under "ICM Method".
Besides, select "TBCP" under "Output Protocol" of "Device Settings" tab.
The following settings can be used as a workaround under the circumstance:
    a. The selection of "ICM Handled by Host System" under "ICM Method";
or
    b. The selection of "ASCII" under "Output Protocol" of "Device Settings"
       tab.

34. Data format, Output Protocol
During installation, if select a port which was created using
SmartDeviceMonitor, the default Output Protocol setting is usually TBCP,
however, it may be ASCII depending on the port name. In such case, please
set it to TBCP manually.

35. Page Layout (N-up) function
When printing in Page Layout (N-up) with selection of Full Bleed Paper Size,
for some applications and OS, the real printed document size may be slightly 
larger than the size printed in normal paper size.

36. Documents that include a "Binary EPS" file
Documents including a "Binary EPS" file might be printed as garbage characters.
Workaround: Apply the following settings to the MFP/Printer and PS3 driver.
For Windows and Macintosh users:
- MFP/Printer: Set the "PS Data Format" setting to "Binary".
For Windows users:
- PS3 driver: Set the "Output Protocol" setting to Binary or ASCII.

37. Scale to Fit
(Windows XP/Server2003/Vista/Server2008/Windows7/Server2012/Windows8)
When printing from certain applications, the "Scale to Fit" function is 
ineffective if the print data contains images.

38. Enable advanced printing features
(Windows XP/Server2003/Vista/Server2008/Windows7/Server2012/Windows8)
The following features can not be used if "Enable advanced printing 
features" is disabled.
    - Booklet
    - Page Order
    - Draw Border
    - Pages per Sheet Layout
    - Booklet Binding Edge

39. Help pointer ("?" button)
(Windows XP/Server2003)
Nothing is displayed if the help pointer is used on an element in Printing 
Preferences. 
(Windows Vista/Server2008/Windows7/Server2012/Windows8)
Nothing is displayed if the help pointer is used on an element in Printing 
Preferences or Printer Properties.

Instead of using the help pointer, please press the "Help" button to get 
information about objects in the driver dialogue.

40. Page Layout (N-up) function
(Windows XP/2003/Vista/Server2008/Windows7/Server2012/Windows8)
If "Pages per Sheet" is 2 or more, pages of mixed orientation documents 
might not be rotated in the way that is expected by the customer.
To make pages rotate differently, please do the following:
(1) Open "Printers and Faxes".
(2) Select a printer and open its Properties.
(3) Open the "Advanced" tab and click the "Print Processor..." button.
(4) Select "WinPrint" from the list of print processors.

41.  Slip Sheets
The PS driver does not support the use of Slip Sheets. 
Even if the device has an interposer, it cannot be configured
as an accessory in the PS driver.

========================================================================
All Names of companies and products in this document are Trademarks or 
Registered Trademarks. 
